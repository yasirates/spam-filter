package com.example.spamfilter

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class SpamFilterApplication : Application()
