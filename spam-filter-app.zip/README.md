# Android Spam SMS Filter

Modern spam mesaj filtreleme uygulaması.

## Kurulum

1. GitHub Actions sekmesinden build'i çalıştırın
2. APK'yı indirin
3. Telefonunuza kurun

## Özellikler

- Otomatik spam tespiti
- Toplu mesaj silme
- Beyaz/Kara liste
- Özelleştirilebilir ayarlar

## Geliştirici

Spam Filter Team
